#define NGS_SDK_VERSION "1.2.5"
