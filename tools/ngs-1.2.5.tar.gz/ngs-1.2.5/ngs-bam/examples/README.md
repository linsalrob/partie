Before trying to build these examples, please run
```
make
make install
```
in `ncbi-vdb` and `ngs` and follow their directions to set the appropriate environment variables.
